import Image from "next/image"
import { Card, CardContent, CardFooter } from "@/components/ui/card"

export default function Testimonials() {
  const testimonials = [
    {
      quote: "Bu web sitesi sayesinde online satışlarımız %40 arttı. Kullanımı çok kolay ve müşterilerimiz çok memnun.",
      author: "Ahmet Yılmaz",
      role: "ABC Şirketi CEO",
      avatar: "/placeholder.svg?height=100&width=100",
    },
    {
      quote: "Profesyonel tasarım ve hızlı destek için teşekkürler. Tam ihtiyacımız olan çözümü sundunuz.",
      author: "Ayşe Kaya",
      role: "XYZ Mağazaları Müdürü",
      avatar: "/placeholder.svg?height=100&width=100",
    },
    {
      quote:
        "Mobil uyumlu tasarım sayesinde müşterilerimiz her yerden sitemize erişebiliyor. Harika bir iş çıkardınız.",
      author: "Mehmet Demir",
      role: "123 Teknoloji Kurucusu",
      avatar: "/placeholder.svg?height=100&width=100",
    },
  ]

  return (
    <section id="testimonials" className="py-16">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Müşteri Yorumları</h2>
            <p className="max-w-[700px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
              Müşterilerimizin bizimle çalışma deneyimleri
            </p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="text-center">
              <CardContent className="pt-6">
                <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center overflow-hidden rounded-full">
                  <Image
                    src={testimonial.avatar || "/placeholder.svg"}
                    alt={testimonial.author}
                    width={100}
                    height={100}
                    className="object-cover"
                  />
                </div>
                <blockquote className="border-l-4 border-primary pl-4 italic">"{testimonial.quote}"</blockquote>
              </CardContent>
              <CardFooter className="flex flex-col">
                <p className="font-semibold">{testimonial.author}</p>
                <p className="text-sm text-gray-500">{testimonial.role}</p>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
