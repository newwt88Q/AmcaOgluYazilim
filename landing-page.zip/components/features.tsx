import { CheckCircle, Zap, Shield, Globe } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function Features() {
  const features = [
    {
      icon: <Zap className="h-10 w-10 text-primary" />,
      title: "Hızlı Performans",
      description: "Yüksek hızlı sunucular ve optimize edilmiş kodlar ile siteniz saniyeler içinde yüklenir.",
    },
    {
      icon: <Shield className="h-10 w-10 text-primary" />,
      title: "Güvenli Altyapı",
      description: "SSL sertifikası ve güncel güvenlik önlemleri ile verileriniz her zaman güvende.",
    },
    {
      icon: <Globe className="h-10 w-10 text-primary" />,
      title: "Mobil Uyumlu",
      description: "Tüm cihazlarda mükemmel görünen responsive tasarım ile her yerde erişilebilirlik.",
    },
    {
      icon: <CheckCircle className="h-10 w-10 text-primary" />,
      title: "SEO Dostu",
      description: "Arama motorlarında üst sıralarda yer almanız için optimize edilmiş yapı.",
    },
  ]

  return (
    <section id="features" className="py-16 bg-gray-50 dark:bg-gray-900">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Özellikler</h2>
            <p className="max-w-[700px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
              Web sitenizi öne çıkaran özelliklerimiz
            </p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <Card key={index} className="border-none shadow-md">
              <CardHeader className="pb-2">
                <div className="mb-2">{feature.icon}</div>
                <CardTitle>{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base">{feature.description}</CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
