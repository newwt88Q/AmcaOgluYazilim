import Image from "next/image"
import { Button } from "@/components/ui/button"

export default function Hero() {
  return (
    <section className="py-20 md:py-28">
      <div className="container px-4 md:px-6">
        <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
          <div className="flex flex-col justify-center space-y-4">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">Modern Web Çözümleri</h1>
              <p className="max-w-[600px] text-gray-500 md:text-xl dark:text-gray-400">
                İşletmeniz için profesyonel, hızlı ve kullanıcı dostu web siteleri. Müşterilerinize en iyi dijital
                deneyimi sunun.
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Button size="lg" className="px-8">
                Ücretsiz Başlayın
              </Button>
              <Button size="lg" variant="outline" className="px-8">
                Demo İzleyin
              </Button>
            </div>
          </div>
          <div className="flex items-center justify-center">
            <div className="relative w-full max-w-[500px] aspect-video overflow-hidden rounded-xl">
              <Image
                src="/placeholder.svg?height=500&width=800"
                alt="Web site görseli"
                width={800}
                height={500}
                className="object-cover"
                priority
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
